
import java.util.Stack;
import javax.swing.ImageIcon;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* *
 *
 * @author Andrea
 */
public class CalculadoraAIS extends javax.swing.JFrame {

    Stack< String> E = new Stack< String>();
    Stack< String> P = new Stack< String>();

    Stack< String> E1 = new Stack< String>();
    Stack< String> P1 = new Stack< String>();

    Boolean igual_reset = false;
    Boolean decimal = false;

    String s = "";
    int numeroParents = 0;

    /**
     * Creates new form CalculadoraAI
     */
    public CalculadoraAIS() {
        initComponents();
        //this.setResizable(false);
        this.setLocationRelativeTo(null);
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/Logo_URJC.svg.png")).getImage());
    }

    private static Double evaluar(String op, String n1, String n2) {
        double num1 = Double.parseDouble(n1);
        double num2 = Double.parseDouble(n2);
        if (op.equals("+")) {
            return (num1 + num2);
        }
        if (op.equals("-")) {
            return (num1 - num2);
        }
        if (op.equals("*")) {
            return (num1 * num2);
        }
        if (op.equals("/")) {
            return (num1 / num2);
        }
        return 0.0;
    }

    private boolean comprobar(String t) {
        if (!t.isEmpty()) {
            boolean operadores = false;
            int abiertos = 0;
            int cerrados = 0;
            boolean aDevolver = true;
            if (t.endsWith(",")) {
                Pantalla.setText("Error: no se puede acabar con ,");
                aDevolver = false;
            }
            for (int i = 0; i < t.length(); i++) {
                if (t.charAt(i) == '+' | t.charAt(i) == 'X' | t.charAt(i) == '/' | t.charAt(i) == '-') {
                    if (!operadores) {
                        operadores = true;
                    } else {
                        Pantalla.setText("Error: varios operadores seguidos");
                        aDevolver = false;
                    }
                } else {
                    if (t.charAt(i) == ',') {
                        if (!operadores) {
                            operadores = true;
                        } else {
                            Pantalla.setText("Error: operador y coma juntos");
                            aDevolver = false;
                        }
                    } else {
                        operadores = false;
                    }
                }
                if (t.charAt(i) == '(') {
                    abiertos++;
                }
                if (t.charAt(i) == ')') {
                    cerrados++;
                }
            }

            if (t.charAt(0) == '+' | t.charAt(0) == 'X' | t.charAt(0) == '/' | t.charAt(0) == '-') {
                Pantalla.setText("Error: No se puede comenzar con un operador");
                aDevolver = false;
            }
            if (t.charAt(t.length() - 1) == '+' | t.charAt(t.length() - 1) == 'X' | t.charAt(t.length() - 1) == '/' | t.charAt(t.length() - 1) == '-') {
                Pantalla.setText("Error: No se puede terminar con un operador");
                aDevolver = false;
            }

            if (abiertos < cerrados) {
                Pantalla.setText("Error: Faltan parentesis de apertura");
                aDevolver = false;
            }
            if (abiertos > cerrados) {
                Pantalla.setText("Error: Faltan parentesis de cierre");
                aDevolver = false;
            }
            return aDevolver;
        }
        return false;
    }

    public void operar() {

        if (!E1.isEmpty()) {
            String operadores = "+-/*()";
            while (!E1.isEmpty()) {
                if (!P1.isEmpty() && operadores.contains(P1.peek())) {
                    String op, num;
                    if (!P1.peek().equals("(")) {
                        op = P1.pop();
                        num = E1.pop();
                        if (P1.isEmpty() || op.equals(")") || (!P1.peek().equals("(") && !P1.peek().equals("*") && !P1.peek().equals("/"))) {
                            P1.push(op);
                            E1.push(num);
                            if (P1.peek().equals(")")) {
                                break;
                            } else {
                                E1.push(Double.toString(evaluar(P1.pop(), E1.pop(), E1.pop())));
                            }
                        } else {
                            if (P1.peek().equals("(")) {
                                do {
                                    P1.pop();
                                    operar();
                                } while (!P1.peek().equals(")"));
                                P1.pop();
                                P1.push(op);
                                E1.push(num);
                            } else {
                                E1.push(Double.toString(evaluar(P1.pop(), E1.pop(), E1.pop())));
                                P1.push(op);
                                E1.push(num);
                            }
                        }
                    } else {
                        if (P1.peek().equals("(")) {
                            do {
                                P1.pop();
                                operar();
                            } while (!P1.peek().equals(")"));
                            P1.pop();
                        } else {
                            E1.push(Double.toString(evaluar(P1.pop(), E1.pop(), E1.pop())));
                        }
                    }
                } else {
                    P1.push(E1.pop());
                }
            }
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Pantalla = new javax.swing.JTextField();
        parentesisAbrir = new javax.swing.JButton();
        numero7 = new javax.swing.JButton();
        numero4 = new javax.swing.JButton();
        numero0 = new javax.swing.JButton();
        parentesisCerrar = new javax.swing.JButton();
        numero8 = new javax.swing.JButton();
        numero5 = new javax.swing.JButton();
        AC = new javax.swing.JButton();
        numero9 = new javax.swing.JButton();
        numero6 = new javax.swing.JButton();
        coma = new javax.swing.JButton();
        division = new javax.swing.JButton();
        multiplicacion = new javax.swing.JButton();
        resta = new javax.swing.JButton();
        igual = new javax.swing.JButton();
        numero1 = new javax.swing.JButton();
        numero2 = new javax.swing.JButton();
        numero3 = new javax.swing.JButton();
        suma = new javax.swing.JButton();
        masMenos = new javax.swing.JButton();
        c = new javax.swing.JButton();
        borrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Calculadora");

        parentesisAbrir.setBackground(new java.awt.Color(0, 0, 0));
        parentesisAbrir.setFont(new java.awt.Font("Tahoma", 1, 21)); // NOI18N
        parentesisAbrir.setForeground(new java.awt.Color(255, 255, 255));
        parentesisAbrir.setText("(");
        parentesisAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                parentesisAbrirActionPerformed(evt);
            }
        });

        numero7.setBorder(null);
        numero7.setBorderPainted(false);
        numero7.setContentAreaFilled(false);
        numero7.setSelected(true);
        numero7.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/numero7.png"))); // NOI18N
        numero7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numero7ActionPerformed(evt);
            }
        });

        numero4.setBorder(null);
        numero4.setBorderPainted(false);
        numero4.setContentAreaFilled(false);
        numero4.setSelected(true);
        numero4.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/numero4.png"))); // NOI18N
        numero4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numero4ActionPerformed(evt);
            }
        });

        numero0.setBorder(null);
        numero0.setBorderPainted(false);
        numero0.setContentAreaFilled(false);
        numero0.setSelected(true);
        numero0.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/numero0.png"))); // NOI18N
        numero0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numero0ActionPerformed(evt);
            }
        });

        parentesisCerrar.setBackground(new java.awt.Color(0, 0, 0));
        parentesisCerrar.setFont(new java.awt.Font("Tahoma", 1, 21)); // NOI18N
        parentesisCerrar.setForeground(new java.awt.Color(255, 255, 255));
        parentesisCerrar.setText(")");
        parentesisCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                parentesisCerrarActionPerformed(evt);
            }
        });

        numero8.setBorder(null);
        numero8.setBorderPainted(false);
        numero8.setContentAreaFilled(false);
        numero8.setSelected(true);
        numero8.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/numero8.png"))); // NOI18N
        numero8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numero8ActionPerformed(evt);
            }
        });

        numero5.setBorder(null);
        numero5.setBorderPainted(false);
        numero5.setContentAreaFilled(false);
        numero5.setSelected(true);
        numero5.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/numero5.png"))); // NOI18N
        numero5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numero5ActionPerformed(evt);
            }
        });

        AC.setBackground(new java.awt.Color(255, 153, 0));
        AC.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        AC.setForeground(new java.awt.Color(255, 255, 255));
        AC.setText("AC");
        AC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ACActionPerformed(evt);
            }
        });

        numero9.setBorder(null);
        numero9.setBorderPainted(false);
        numero9.setContentAreaFilled(false);
        numero9.setSelected(true);
        numero9.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/numero9.png"))); // NOI18N
        numero9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numero9ActionPerformed(evt);
            }
        });

        numero6.setBorder(null);
        numero6.setBorderPainted(false);
        numero6.setContentAreaFilled(false);
        numero6.setSelected(true);
        numero6.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/numero6.png"))); // NOI18N
        numero6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numero6ActionPerformed(evt);
            }
        });

        coma.setBackground(new java.awt.Color(0, 0, 0));
        coma.setFont(new java.awt.Font("Tahoma", 1, 21)); // NOI18N
        coma.setForeground(new java.awt.Color(255, 255, 255));
        coma.setText(",");
        coma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comaActionPerformed(evt);
            }
        });

        division.setBackground(new java.awt.Color(0, 0, 0));
        division.setFont(new java.awt.Font("Tahoma", 1, 21)); // NOI18N
        division.setForeground(new java.awt.Color(255, 255, 255));
        division.setText("/");
        division.setPreferredSize(new java.awt.Dimension(50, 50));
        division.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                divisionActionPerformed(evt);
            }
        });

        multiplicacion.setBackground(new java.awt.Color(0, 0, 0));
        multiplicacion.setFont(new java.awt.Font("Tahoma", 1, 21)); // NOI18N
        multiplicacion.setForeground(new java.awt.Color(255, 255, 255));
        multiplicacion.setText("x");
        multiplicacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                multiplicacionActionPerformed(evt);
            }
        });

        resta.setBackground(new java.awt.Color(0, 0, 0));
        resta.setFont(new java.awt.Font("Tahoma", 1, 21)); // NOI18N
        resta.setForeground(new java.awt.Color(255, 255, 255));
        resta.setText("-");
        resta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restaActionPerformed(evt);
            }
        });

        igual.setBackground(new java.awt.Color(0, 0, 0));
        igual.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        igual.setForeground(new java.awt.Color(255, 255, 255));
        igual.setText("=");
        igual.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        igual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                igualActionPerformed(evt);
            }
        });

        numero1.setBackground(new java.awt.Color(255, 255, 255));
        numero1.setSelected(true);
        numero1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/numero1.png"))); // NOI18N
        numero1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numero1ActionPerformed(evt);
            }
        });

        numero2.setBorder(null);
        numero2.setBorderPainted(false);
        numero2.setContentAreaFilled(false);
        numero2.setSelected(true);
        numero2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/numero2.png"))); // NOI18N
        numero2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numero2ActionPerformed(evt);
            }
        });

        numero3.setBorder(null);
        numero3.setBorderPainted(false);
        numero3.setContentAreaFilled(false);
        numero3.setSelected(true);
        numero3.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/numero3.png"))); // NOI18N
        numero3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numero3ActionPerformed(evt);
            }
        });

        suma.setBackground(new java.awt.Color(0, 0, 0));
        suma.setFont(new java.awt.Font("Tahoma", 1, 21)); // NOI18N
        suma.setForeground(new java.awt.Color(255, 255, 255));
        suma.setText("+");
        suma.setPreferredSize(new java.awt.Dimension(50, 50));
        suma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sumaActionPerformed(evt);
            }
        });

        masMenos.setBackground(new java.awt.Color(0, 0, 0));
        masMenos.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        masMenos.setForeground(new java.awt.Color(255, 255, 255));
        masMenos.setText("+/-");
        masMenos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                masMenosActionPerformed(evt);
            }
        });

        c.setBackground(new java.awt.Color(0, 0, 0));
        c.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        c.setForeground(new java.awt.Color(255, 255, 255));
        c.setText("c");
        c.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cActionPerformed(evt);
            }
        });

        borrar.setBackground(new java.awt.Color(0, 0, 0));
        borrar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        borrar.setForeground(new java.awt.Color(255, 255, 255));
        borrar.setBorderPainted(false);
        borrar.setSelected(true);
        borrar.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/aiga-down-arrow-bg-146992.png"))); // NOI18N
        borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Pantalla, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(numero7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(numero8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(numero9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(numero1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(numero2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(numero3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(suma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(multiplicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(resta, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(numero0, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(coma, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(igual, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(numero4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(numero5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(numero6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(masMenos, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(borrar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(c, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(AC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(parentesisAbrir, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(parentesisCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(division, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(Pantalla, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(c, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(borrar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AC, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(parentesisAbrir, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(parentesisCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(division, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(masMenos, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(multiplicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(numero9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(numero8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(numero7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(numero5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(numero4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(suma, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(numero6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(resta, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(numero1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(numero2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(numero3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(numero0, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(coma, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(igual, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void parentesisAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_parentesisAbrirActionPerformed
        // TODO add your handling code here:
        if (igual_reset == true) {
            igual_reset = false;
            s = "";
            E.clear();
        }
        s = s + "(";
        P.push("(");
        numeroParents++;
        Pantalla.setText(s);
    }//GEN-LAST:event_parentesisAbrirActionPerformed

    private void numero7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numero7ActionPerformed
        // TODO add your handling code here:
        if (igual_reset == true) {
            igual_reset = false;
            s = "";
            E.clear();
        }
        s = s + "7";
        if (E.size() - P.size() >= 1 - numeroParents) {
            E.push(E.pop() + "7");
        } else {
            E.push("7");
        }
        Pantalla.setText(s);
    }//GEN-LAST:event_numero7ActionPerformed

    private void multiplicacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_multiplicacionActionPerformed
        // TODO add your handling code here:
        igual_reset = false;
        decimal = false;
        s = s + "X";
        P.push("*");
        Pantalla.setText(s);
    }//GEN-LAST:event_multiplicacionActionPerformed

    private void restaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restaActionPerformed
        // TODO add your handling code here:
        igual_reset = false;
        decimal = false;
        s = s + "-";
        P.push("-");
        Pantalla.setText(s);
    }//GEN-LAST:event_restaActionPerformed

    private void comaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comaActionPerformed
        // TODO add your handling code here:
        String p = Pantalla.getText();
        if (igual_reset) {
            igual_reset = false;
            s = "";
            E.clear();
        } else {
            if (!E.isEmpty()) {
                if ((p.charAt(p.length() - 1) != ',') && (!decimal)) {
                    s = s + ",";
                    E.push(E.pop() + ".");

                    decimal = true;
                }
            }
        }
        Pantalla.setText(s);
    }//GEN-LAST:event_comaActionPerformed

    private void numero1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numero1ActionPerformed
        // TODO add your handling code here:
        if (igual_reset == true) {
            igual_reset = false;
            s = "";
            E.clear();
        }
        s = s + "1";
        if (E.size() - P.size() >= 1 - numeroParents) {
            E.push(E.pop() + "1");
        } else {
            E.push("1");
        }
        Pantalla.setText(s);
    }//GEN-LAST:event_numero1ActionPerformed

    private void numero2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numero2ActionPerformed
        // TODO add your handling code here:
        if (igual_reset == true) {
            igual_reset = false;
            s = "";
            E.clear();
        }
        s = s + "2";
        if (E.size() - P.size() >= 1 - numeroParents) {
            E.push(E.pop() + "2");
        } else {
            E.push("2");
        }
        Pantalla.setText(s);
    }//GEN-LAST:event_numero2ActionPerformed

    private void numero3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numero3ActionPerformed
        // TODO add your handling code here:

        if (igual_reset == true) {
            igual_reset = false;
            s = "";
            E.clear();
        }
        s = s + "3";
        if (E.size() - P.size() >= 1 - numeroParents) {
            E.push(E.pop() + "3");
        } else {
            E.push("3");
        }
        Pantalla.setText(s);
    }//GEN-LAST:event_numero3ActionPerformed

    private void numero4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numero4ActionPerformed
        // TODO add your handling code here:
        if (igual_reset == true) {
            igual_reset = false;
            s = "";
            E.clear();
        }
        s = s + "4";
        if (E.size() - P.size() >= 1 - numeroParents) {
            E.push(E.pop() + "4");
        } else {
            E.push("4");
        }
        Pantalla.setText(s);
    }//GEN-LAST:event_numero4ActionPerformed

    private void numero5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numero5ActionPerformed
        // TODO add your handling code here:
        if (igual_reset == true) {
            igual_reset = false;
            s = "";
            E.clear();
        }
        s = s + "5";
        if (E.size() - P.size() >= 1 - numeroParents) {
            E.push(E.pop() + "5");
        } else {
            E.push("5");
        }
        Pantalla.setText(s);
    }//GEN-LAST:event_numero5ActionPerformed

    private void numero6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numero6ActionPerformed
        // TODO add your handling code here:
        if (igual_reset == true) {
            igual_reset = false;
            s = "";
            E.clear();
        }
        s = s + "6";
        if (E.size() - P.size() >= 1 - numeroParents) {
            E.push(E.pop() + "6");
        } else {
            E.push("6");
        }
        Pantalla.setText(s);
    }//GEN-LAST:event_numero6ActionPerformed

    private void numero8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numero8ActionPerformed
        // TODO add your handling code here;
        if (igual_reset == true) {
            igual_reset = false;
            s = "";
            E.clear();
        }
        s = s + "8";
        if (E.size() - P.size() >= 1 - numeroParents) {
            E.push(E.pop() + "8");
        } else {
            E.push("8");
        }
        Pantalla.setText(s);
    }//GEN-LAST:event_numero8ActionPerformed

    private void numero9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numero9ActionPerformed
        // TODO add your handling code here:
        if (igual_reset == true) {
            igual_reset = false;
            s = "";
            E.clear();
        }
        s = s + "9";
        if (E.size() - P.size() >= 1 - numeroParents) {
            E.push(E.pop() + "9");
        } else {
            E.push("9");
        }
        Pantalla.setText(s);
    }//GEN-LAST:event_numero9ActionPerformed

    private void divisionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_divisionActionPerformed
        // TODO add your handling code here:
        igual_reset = false;
        decimal = false;
        s = s + "/";
        P.push("/");
        Pantalla.setText(s);
    }//GEN-LAST:event_divisionActionPerformed

    private void sumaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sumaActionPerformed
        // TODO add your handling code here:
        igual_reset = false;
        decimal = false;
        s = s + "+";
        P.push("+");
        Pantalla.setText(s);
    }//GEN-LAST:event_sumaActionPerformed

    private void parentesisCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_parentesisCerrarActionPerformed
        // TODO add your handling code here:
        s = s + ")";
        P.push(")");
        numeroParents++;
        Pantalla.setText(s);
    }//GEN-LAST:event_parentesisCerrarActionPerformed

    private void ACActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ACActionPerformed
        // TODO add your handling code here:
        decimal = false;
        numeroParents = 0;
        s = "";
        E.removeAllElements();
        P.removeAllElements();
        E1.removeAllElements();
        P1.removeAllElements();
        Pantalla.setText(s);
    }//GEN-LAST:event_ACActionPerformed

    private void numero0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numero0ActionPerformed
        // TODO add your handling code here:
        if (igual_reset == true) {
            igual_reset = false;
            s = "";
            E.clear();
        }
        s = s + "0";
        if (E.size() - P.size() >= 1 - numeroParents) {
            E.push(E.pop() + "0");
        } else {
            E.push("0");
        }
        Pantalla.setText(s);
    }//GEN-LAST:event_numero0ActionPerformed

    private void igualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_igualActionPerformed
        // TODO add your handling code here:
        String comprobarEntrada = Pantalla.getText();
        if (comprobar(comprobarEntrada)) {
            igual_reset = true;
            decimal = false;

            while (!E.isEmpty()) {
                E1.push(E.pop());
            }
            while (!P.isEmpty()) {
                P1.push(P.pop());
            }
            operar();

            E.push(P1.pop());
            s = E.peek();
            Pantalla.setText(s);
            numeroParents = 0;
        }

    }//GEN-LAST:event_igualActionPerformed

    private void masMenosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_masMenosActionPerformed
        if (!E.isEmpty()) {
            String simbolo = Pantalla.getText();
            if (!simbolo.endsWith("+") && !simbolo.endsWith("-") && !simbolo.endsWith("X") && !simbolo.endsWith("/")) {
                String c = E.peek();
                String aDevolver;
                if (simbolo.charAt(simbolo.length()-1) == ')') {
                    c = c.substring(1, E.peek().length());
                    aDevolver = simbolo.substring(0, simbolo.length() - (E.peek().length() + 2)) + c;
                } else if(c.contains("-")){
                    c = c.substring(1, E.peek().length());
                    aDevolver = simbolo.substring(0, simbolo.length() - (E.peek().length())) + c;
                } else {
                    c = "-" + c;
                    aDevolver = simbolo.substring(0, simbolo.length() - E.peek().length()) + "(" + c + ")";
                }
                E.pop();
                E.push(c);
                s = aDevolver;
                Pantalla.setText(aDevolver);
            }
        }
    }//GEN-LAST:event_masMenosActionPerformed

    private void cActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cActionPerformed
        if (!E.isEmpty() || !E1.isEmpty()) {
            String p = Pantalla.getText();
            String aDevolver = p;
            if (p.charAt(p.length() - 1) != '+' && p.charAt(p.length() - 1) != '-' && p.charAt(p.length() - 1) != 'X' && p.charAt(p.length() - 1) != '/' && p.charAt(p.length() - 1) != '(') {
                if (p.charAt(p.length() - 1) == ')') {
                    if (E.peek().contains("-")) {
                        aDevolver = p.substring(0, p.length() - (E.peek().length() + 2));
                        E.pop();
                        s = aDevolver;
                    }
                } else {
                    aDevolver = p.substring(0, p.length() - E.peek().length());
                    E.pop();
                    s = aDevolver;
                }
            }
            Pantalla.setText(aDevolver);
            decimal = false;
        }
    }//GEN-LAST:event_cActionPerformed

    private void borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrarActionPerformed
        // TODO add your handling code here:
        if (!E.isEmpty() || !E1.isEmpty()) {
            String p = Pantalla.getText();
            String aDevolver = p;
            if (p.charAt(p.length() - 1) != '+' && p.charAt(p.length() - 1) != '-' && p.charAt(p.length() - 1) != 'X' && p.charAt(p.length() - 1) != '/' && p.charAt(p.length() - 1) != '(') {
                if (p.charAt(p.length() - 1) == ')') {
                    if (E.peek().contains("-")) {
                        String numero = E.pop();
                        if(numero.length() == 2){
                            aDevolver = p.substring(0, p.length() - (numero.length() + 2));
                        }
                        else{
                            numero=numero.substring(0, numero.length()-1);
                            aDevolver = p.substring(0, p.length() - (numero.length() + 2))+numero+")";
                            E.push(numero);
                        }

                        s = aDevolver;
                    }
                } else {
                    aDevolver = p.substring(0, p.length()-1);
                    if(E.peek().length()==1){
                    E.pop();
                    }
                    else{
                        String numero = E.pop();
                        E.push(numero.substring(0, numero.length()-1));
                    }
                    s = aDevolver;
                }
            }
            Pantalla.setText(aDevolver);
            decimal = false;
        }
    }//GEN-LAST:event_borrarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CalculadoraAIS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CalculadoraAIS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CalculadoraAIS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CalculadoraAIS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        CalculadoraAIS cal = new CalculadoraAIS();
        cal.setVisible(true);

        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new CalculadoraAIS().setVisible(true);
//            }
//        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AC;
    private javax.swing.JTextField Pantalla;
    private javax.swing.JButton borrar;
    private javax.swing.JButton c;
    private javax.swing.JButton coma;
    private javax.swing.JButton division;
    private javax.swing.JButton igual;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton masMenos;
    private javax.swing.JButton multiplicacion;
    private javax.swing.JButton numero0;
    private javax.swing.JButton numero1;
    private javax.swing.JButton numero2;
    private javax.swing.JButton numero3;
    private javax.swing.JButton numero4;
    private javax.swing.JButton numero5;
    private javax.swing.JButton numero6;
    private javax.swing.JButton numero7;
    private javax.swing.JButton numero8;
    private javax.swing.JButton numero9;
    private javax.swing.JButton parentesisAbrir;
    private javax.swing.JButton parentesisCerrar;
    private javax.swing.JButton resta;
    private javax.swing.JButton suma;
    // End of variables declaration//GEN-END:variables
}
